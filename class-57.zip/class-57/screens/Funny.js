import React, { Component } from 'react';
import { Text, View,TouchableOpacity, StyleSheet } from 'react-native';

export default class Funny extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Text style={{ fontSize:30, backgroundColor:"lightblue"}}> Funny Facts </Text>
        <Text> </Text>
        <Text style={styles.points}>1) The little dot over the 'i' and 'j' is called a tittle.</Text>
        <Text> </Text>
        <Text style={styles.points} >2) Water makes different sounds when being poured at different temperatures.</Text>
        <Text> </Text>
        <Text style={styles.points}>3) Rabbits can not become sick.</Text>
        <Text> </Text>
        <Text style={styles.points}>4) The hashtag symbol (#) has a fancy name which is an octothorp.</Text>
        <Text> </Text>
        <Text style={styles.points}>5) You can draw one straight line lasting 35 miles with one regular pencil.</Text>
        <Text> </Text>
        <TouchableOpacity
              style={styles.buttons}
              onPress={() => this.props.navigation.navigate('HomeScreen')}>
              <Text style={{ fontSize:20, color:"white"}}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container:{ 
     alignItems: 'center',
     justifyContent: 'center',
     marginTop: 100 
    },
  points:{
    fontSize: 20
  },  buttons: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 15,
    backgroundColor:"green",
    margin: 10,
    width: 200,
    height: 50,
  }
})