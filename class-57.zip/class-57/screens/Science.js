import React, { Component } from 'react';
import { Text, View, TouchableOpacity,StyleSheet } from 'react-native';

export default class Science extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Text style={{ fontSize:30, backgroundColor:"yellow"}}> Science Facts </Text>
        <Text> </Text>
        <Text style={styles.points}>1) The strongest muscle in the human body is the tongue.</Text>
         <Text> </Text>
        <Text style={styles.points} >2) A potato is able to power a clock.</Text>
         <Text> </Text>
        <Text style={styles.points} >3) Sound travels 4 times faster than water than in air.</Text>
         <Text> </Text>
        <Text style={styles.points} >4) The human brain is composed of 78% water</Text>
         <Text> </Text>
        <Text style={styles.points} >5) Helium has the aility to work against gravity.</Text>
         <Text> </Text>
        <TouchableOpacity
              style={styles.buttons}
              onPress={() => this.props.navigation.navigate('HomeScreen')}>
              <Text style={{ fontSize:20, color:"white"}}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container:{ 
     alignItems: 'center',
     justifyContent: 'center',
     marginTop: 100 
    },
  points:{
    fontSize: 20
  },
    buttons: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 15,
    backgroundColor:"green",
    margin: 10,
    width: 200,
    height: 50,
  }
})